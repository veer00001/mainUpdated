import React from 'react'
import { Appservices } from "../../../data/data";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHouse } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import Col from 'react-bootstrap/Col';
import Nav from 'react-bootstrap/Nav';
import Row from 'react-bootstrap/Row';
import Tab from 'react-bootstrap/Tab';
import { AppservicesDemo } from "../../../data/data";

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import Card from 'react-bootstrap/Card';

const DigitalMarketing = () => {
  return (
    <div>
      <div>
        <div className="container  seoTopSection">
          <div>
            <h2>
              Our Digital Marketing Services</h2>
            <p>
              Maximize the impact of your online footprint through our Digital Marketing Services. Our skilled team provides a full range of digital marketing solutions, spanning SEO, social media, and pay-per-click advertising. We customize strategies to align seamlessly with your specific objectives, guaranteeing your success in the ever-evolving digital sphere.
            </p>

            <ul>
              <li>Unmatched Expertis</li>
              <li>24/7 Support</li>
              <li>Professional Staff</li>
              <li>Fair Prices</li>
            </ul>
          </div>
          <span>
            <img
              src="https://images.unsplash.com/photo-1562577309-2592ab84b1bc?q=80&w=1674&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt="image missing"
            />
          </span>
        </div>

        <Tab.Container id="left-tabs-example" defaultActiveKey="first">
          <Row m={0} className="m-0" >
            <Col sm={2}>
              <Nav variant="pills" className="flex-column  demoList">
                <Nav.Item>
                  <Nav.Link eventKey="first">App SERVICES/PRICING</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="2">Web app Demo</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="3">Legacy app Demo</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="4">Hybrid apps Demo</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="5">Desktop apps Demo</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="6">Native  apps Demo</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="7">Progressive web apps</Nav.Link>
                </Nav.Item>
              </Nav>
            </Col>
            <Col sm={9}>
              <Tab.Content>
                <Tab.Pane eventKey="first">
                  <div className="seoServices  container">
                    <h2>App SERVICES WE PROVIED</h2>
                    <div className="seoServicesBoxParant">
                      {Appservices.map((data) => (
                        <div>
                          <span>
                            {" "}
                            <FontAwesomeIcon icon={faHouse} />
                            {/* <img src="" alt="image missing" />{" "} */}
                          </span>
                          <h4> {data.name}</h4>
                          <p>{data.Description}</p>
                          <p>
                            {" "}
                            <Link to=""> Read More </Link>
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="SEOpricingTable">
                    <div class="container">
                      <div class="row">
                        <div class="col-md-12 mb-5">
                          <h2 class="main-head">PRICING</h2>
                        </div>

                        <div class="col-md-4">
                          <div class="pricing-table purple">

                            <div class="pricing-label">Fixed Price</div>
                            <h2>BasicPack 2020</h2>
                            <h5>Made for starters</h5>

                            <div class="pricing-features">
                              <div class="feature">Bandwith<span>50 GB</span></div>
                              <div class="feature">Add-On Domains<span>10</span></div>
                              <div class="feature">SSD Storage<span>250 GB</span></div>
                              <div class="feature">Mail Adresses<span>25</span></div>
                              <div class="feature">Support<span>Only Mail</span></div>
                            </div>

                            <div class="price-tag">
                              <span class="symbol">$</span>
                              <span class="amount">7.99</span>
                              <span class="after">/month</span>
                            </div>

                            <a class="price-button" href="#">Get Started</a>
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="pricing-table turquoise">

                            <div class="pricing-label">Fixed Price</div>
                            <h2>ExtendedPack 2020</h2>
                            <h5>Made for experienced users</h5>

                            <div class="pricing-features">
                              <div class="feature">Bandwith<span>150 GB</span></div>
                              <div class="feature">Add-On Domains<span>25</span></div>
                              <div class="feature">SSD Storage<span>500 GB</span></div>
                              <div class="feature">Mail Adresses<span>50</span></div>
                              <div class="feature">Support<span>Mail/Phone</span></div>
                            </div>

                            <div class="price-tag">
                              <span class="symbol">$</span>
                              <span class="amount">9.99</span>
                              <span class="after">/month</span>
                            </div>

                            <a class="price-button" href="#">Get Started</a>
                          </div>
                        </div>

                        <div class="col-md-4">
                          <div class="pricing-table red">

                            <div class="pricing-label">Fixed Price</div>
                            <h2>ProsPack 2020</h2>
                            <h5>Made for professionals/agencies</h5>

                            <div class="pricing-features">
                              <div class="feature">Bandwith<span>250 GB</span></div>
                              <div class="feature">Add-On Domains<span>50</span></div>
                              <div class="feature">SSD Storage<span>1 TB</span></div>
                              <div class="feature">Mail Adresses<span>75</span></div>
                              <div class="feature">Support<span>7/24</span></div>
                            </div>

                            <div class="price-tag">
                              <span class="symbol">$</span>
                              <span class="amount">12.99</span>
                              <span class="after">/month</span>
                            </div>

                            <a class="price-button" href="#">Get Started</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </Tab.Pane>
                <Tab.Pane eventKey="2">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>
                <Tab.Pane eventKey="3">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>
                <Tab.Pane eventKey="4">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>
                <Tab.Pane eventKey="5">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>
                <Tab.Pane eventKey="6">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>
                <Tab.Pane eventKey="7">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>
                <Tab.Pane eventKey="8">
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={3}
                    onSlideChange={() => console.log('slide change')}
                    onSwiper={(swiper) => console.log(swiper)}
                  >

                    {
                      AppservicesDemo.map((data) =>
                        <SwiperSlide>
                          <Card style={{ width: '18rem' }} className="demoCardsParant">
                            <img src={data.img} alt="img" />
                            <Card.Body>
                              <h4>{data.name}</h4>
                              <Card.Text>
                                {data.Description}
                              </Card.Text>
                              <h6>
                                status : <strong>"{data.status}" </strong>
                              </h6>
                              <Link to={data.link}> Visit To app  </Link>
                            </Card.Body>
                          </Card>
                        </SwiperSlide>
                      )
                    }
                  </Swiper>


                </Tab.Pane>

              </Tab.Content>
            </Col>
          </Row>
        </Tab.Container>



        {/* pricing Table */}




      </div>
    </div>
  )
}

export default DigitalMarketing