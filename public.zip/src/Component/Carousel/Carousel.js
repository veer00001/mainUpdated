import React from "react";
import "./Carousel.css";
import Carousel from "react-bootstrap/Carousel";
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom'
import { mainBanner } from "../../data/data";

// import ExampleCarouselImage from "components/ExampleCarouselImage";

const MainBanner = () => {
  return (
    <div className="mainBanner">
      <Carousel>
        {
          mainBanner.map((data) =>
            <Carousel.Item interval={1000}>
              {/* <ExampleCarouselImage text="First slide" /> */}
              <img src={data.img} className="bannerImages" alt="" />
              <Carousel.Caption>
                <h3>{data.name} </h3>
                <p>
                  {data.Description}
                </p>
                <div className="banner-benifit">
                  <li>Improve Brand Visibility </li>
                  <li> Increase Quality Traffic</li>
                  <li> Maximize ROI</li>
                  <li> Fast Results</li>
                </div>
                <div className="banner-button-parant">
                  <Button variant="primary"><Link to={data.link}> Read More</Link></Button>{' '}
                  <Button variant="primary"><Link to="">Get In Touch </Link></Button>{' '}
                </div>
              </Carousel.Caption>
            </Carousel.Item>

          )
        }


      </Carousel>
    </div>
  );
};

export default MainBanner;
