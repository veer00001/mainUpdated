import React from "react";
import "./OurTeam.css";
import { ourTestimonial } from "../../../data/data";

const OurTeam = () => {
  return (
    <div className="OurTeamParant">
      <div className="ourTeams">
        <div className="meetmy">
          <h2>
            Meet the <br /> Team
          </h2>
          <p>
            This is sample text. insert your desired text here This is sample
            text. insert your
          </p>
        </div>
      </div>
      <div className="ourTeam">
        {
          ourTestimonial.map((data)=>
          <div className="ourTeamImgTextParant">
          <span>
            <img src={data.img} />  </span>
          <div>
            <li>{data.name}</li>
            <li>{data.profession}</li>
          </div>
        </div>
          )
        }
       
      </div>
    </div>
  );
};
export default OurTeam;
