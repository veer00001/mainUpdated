import React from "react";
import "./AboutusTimline.css";
import { MDBCard, MDBCardBody, MDBContainer } from "mdb-react-ui-kit";
import { MDBBtn, MDBCol, MDBRow, MDBTypography } from "mdb-react-ui-kit";

const AboutusTimline = () => {
  return (
    <div className="aboutusTImelineParant">
      <div className="headingprocess">
        <h2>Our Working Process</h2>
      </div>

      <div >
        <MDBContainer fluid className="py-5">
          <MDBRow>
            <MDBCol lg="12">
              <div className="horizontal-timeline">
                <MDBTypography listInLine className="items">
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-info">Step 1</div>
                      <h5 className="pt-2">Planning</h5>
                      <p className="text-muted">

                        Planning is a critical phase in any project or endeavor, providing the foundation for success.
                      </p>

                    </div>
                  </li>
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-success">Step 2</div>
                      <h5 className="pt-2">Research</h5>
                      <p className="text-muted">
                        Research is a fundamental component of our approach at WebEach Tech, ensuring that we stay at the forefront of technology and design trends.
                      </p>

                    </div>
                  </li>
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-danger">Step 3</div>
                      <h5 className="pt-2">Optimizing</h5>
                      <p className="text-muted">
                        Optimizing is a key focus at WebEach Tech, and it encompasses several aspects to ensure our app development and design services are efficient, effective, and future-ready:
                      </p>
                      <div>

                      </div>
                    </div>
                  </li>
                  <li className="items-list">
                    <div className="px-4">
                      <div className="event-date badge bg-warning">Step 4</div>
                      <h5 className="pt-2">Result</h5>
                      <p className="text-muted">

                        The result of our  services at WebEach Tech is a culmination of meticulous planning, comprehensive research, and rigorous optimization. Our clients can expect:
                      </p>
                      <div>

                      </div>
                    </div>
                  </li>
                </MDBTypography>
              </div>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </div>

      <MDBContainer
        fluid
        className="py-5"
        style={{ backgroundColor: "#F0F2F5" }}
      >
        <div className="main-timeline">
          <div className="timeline left">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2024</h3>
                <p className="mb-0">
                  This year, our main focus is to build a strong global presence. We aim to strengthen our foundation, gain initial recognition in the market, and position our business for long-term growth. Our goal is to create a solid and flexible framework that can adapt to different market conditions, ensuring lasting success on an international level.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>
          <div className="timeline right">
            <MDBCard>
              <MDBCardBody className="p-4">
                <h3>2025</h3>
                <p className="mb-0">
                  "Our strategic vision at WebEach Teach is to position ourselves among the top 10 web service providers globally by the conclusion of the year 2025.
                </p>
              </MDBCardBody>
            </MDBCard>
          </div>

        </div>
      </MDBContainer>
    </div>
  );
};

export default AboutusTimline;
