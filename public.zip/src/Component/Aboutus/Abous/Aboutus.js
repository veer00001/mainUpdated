import React from "react";
import "./Aboutus.css";
import AboutusTimline from "./AboutusTimline/AboutusTimline";

const Aboutus = () => {
  return (
    <div>
      <div className="abutusbanner">
        <h2>WELCOME TO WebEach Tech</h2>
        <p>Welcome to WebEach Tech! 🚀 We're your go-to destination for cutting-edge app development and design services.</p>
      </div>
      <div className="aboutussection">
        <div>
          <h1>About us</h1>
          <p>
            "Welcome to WebEach Tech, where digital innovation meets seamless execution. As a dynamic team of skilled developers and designers, we pride ourselves on transforming concepts into extraordinary digital solutions. At WebEach Tech, we specialize in crafting user-centric experiences, be it through mobile apps, web development, or cross-platform solutions.
          </p>
          <p>
            Our commitment to excellence ensures that every project we undertake exceeds expectations. Join us in the journey of pushing boundaries, shaping the digital landscape, and making your ideas a digital reality. Explore endless possibilities with WebEach Tech – your partner in innovation and design."
          </p>
        </div>
        <span className="aboutussideimg">
          <img src="https://images.unsplash.com/photo-1551135049-8a33b5883817?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" />{" "}
        </span>
      </div>
      <div>
        <AboutusTimline />
      </div>
    </div>
  );
};

export default Aboutus;
