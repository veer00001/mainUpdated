import React from "react";
import "./WebsiteDesign.css";
import Carousel from "react-bootstrap/Carousel";
import { webDesign } from "../../data/data";
import Webdesigningproject from "./Webdesigningproject/Webdesigningproject";

const WebsiteDesign = () => {
  return (
    <div className="websiteParant">
      <Carousel>
        <Carousel.Item>
          <img
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1744&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="img"
          />
          <Carousel.Caption>
            <h3>First slide label</h3>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1744&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="img"
          />
          <Carousel.Caption>
            <h3>Second slide label</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1744&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="img"
          />
          <Carousel.Caption>
            <h3>Third slide label</h3>
            <p>
              Praesent commodo cursus magna, vel scelerisque nisl consectetur.
            </p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      <div className="webDesignBoxparant">
        <h2>Web Design Services</h2>

        <div
          className="webDesignservices container"
          style={{ backgroundImage: `url('')` }}
        >
          {webDesign.map((data) => (
            <div className="webDesignbox">
              <h4>{data.technology}</h4>
              <p>{data.Description} </p>
            </div>
          ))}
        </div>
      </div>

      <Webdesigningproject />
    </div>
  );
};

export default WebsiteDesign;
