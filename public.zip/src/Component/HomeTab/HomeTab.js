import React from "react";
import "./HomeTab.css";
import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Row from "react-bootstrap/Row";
import Tab from "react-bootstrap/Tab";
import { Link } from "react-router-dom";
import { AppDevelopmentDesign, GraphicDesign, DigitalMarketing, WebDevelopmentDesign, Hosting } from "../../data/data";


const HomeTab = () => {
  return (
    <div className="homeTab-parant">
      <Tab.Container id="left-tabs-example" defaultActiveKey="first">
        <Row>
          <Col sm={3} className="tabHeading">
            <Nav variant="pills" className="flex-column">
              <Nav.Item>
                <Nav.Link eventKey="first"> App Development/Design</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="second"> Web Development/Design</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Thrid">Digital Marketing</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Fourth">Graphic Designing</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="Five">Hosting</Nav.Link>
              </Nav.Item>

            </Nav>
          </Col>
          <Col sm={9}>
            <Tab.Content className="" style={{ height: "100%" }}>
              <Tab.Pane eventKey="first">
                <h2>  App Development/Design </h2>
                <p>
                  "At 'webeach,' we turn ideas into exceptional digital experiences. Our skilled team crafts user-centric applications, specializing in mobile, web, and cross-platform solutions. From concept to deployment, we're committed to excellence, ensuring every app exceeds expectations. Elevate your digital presence with 'webeach' – where innovation meets design."
                </p>
                <div className="tab-images-text-parant">
                  {AppDevelopmentDesign.map((data) =>
                    <ul>
                      <li>
                        {" "}
                        <img src={data.img} />
                      </li>

                      <li>
                        {" "}
                        <Link to='/AppDevelopment'>{data.name} </Link>{" "}
                      </li>
                    </ul>

                  )}


                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="second">
                <h2> Web Development/Design</h2>
                <p>
                  " Web Brain InfoTech delivers top-notch, affordable web
                  development services tailored to client preferences. Whether
                  it's crafting visually appealing websites or optimizing for
                  search engines, we exceed expectations. Our innovative
                  developers seamlessly blend creative design and smart
                  technology, ensuring your website is future-ready for success
                  in the digital realm. "
                </p>
                <div className="tab-images-text-parant">

                  {WebDevelopmentDesign.map((data) =>
                    <ul>
                      <li>
                        {" "}
                        <img src={data.img} />
                      </li>

                      <li>
                        {" "}
                        <Link to='/WebDevelopment'>{data.name} </Link>{" "}
                      </li>
                    </ul>

                  )}

                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Thrid">
                <h2> Digital Marketing </h2>
                <p>
                  " Google is a household name, and we all use search engines
                  regularly. Your search query is what you type into the search
                  box, leading you to a Search Engine Results Page (SERP).
                  Search Engine Optimization (SEO) is crucial for top search
                  rankings, involving keyword tweaks, content optimization, and
                  link building. For effective SEO services in India, consider
                  affordable options to elevate your brand on search engine "
                </p>
                <div className="tab-images-text-parant">
                  {DigitalMarketing.map((data) =>
                    <ul>
                      <li>
                        {" "}
                        <img src={data.img} />
                      </li>

                      <li>
                        {" "}
                        <Link to='/DigitalMarketing'>{data.name} </Link>{" "}
                      </li>
                    </ul>

                  )}
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Fourth">
                <h2> Graphic Designing </h2>
                <p>
                  " In the modern era, businesses have evolved beyond desktops
                  and laptops, embracing the widespread use of easily accessible
                  apps. With smartphones becoming ubiquitous, businesses can tap
                  into a vast customer base by transforming their ideas into
                  user-friendly mobile applications. The prevalence of
                  smartphones makes it an ideal platform to target potential
                  customers, regardless of the nature of the business or service
                  offered. Apps have become an essential tool for reaching and
                  engaging with a diverse audience, ensuring business success in
                  today's dynamic market. "
                </p>
                <div className="tab-images-text-parant">
                  {GraphicDesign.map((data) =>
                    <ul>
                      <li>
                        {" "}
                        <img src={data.img} />
                      </li>

                      <li>
                        {" "}
                        <Link to='/Grahic'>{data.name} </Link>{" "}
                      </li>
                    </ul>

                  )}
                </div>
              </Tab.Pane>

              <Tab.Pane eventKey="Five">
                <h2> Hosting</h2>
                <p>

                  Enhance your digital presence with our cutting-edge web hosting services. Experience swift, secure, and dependable hosting solutions customized to meet your unique requirements. Rely on our round-the-clock support and ensure the optimal performance to keep your website operating seamlessl
                </p> 
                <div className="tab-images-text-parant">
                  {Hosting.map((data) =>
                    <ul>
                      <li>
                        {" "}
                        <img src={data.img} />
                      </li>

                      <li>
                        {" "}
                        <Link to='/Hosting'>{data.name} </Link>{" "}
                      </li>
                    </ul>

                  )}




                </div>
              </Tab.Pane>


            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </div>
  );
};

export default HomeTab; 
