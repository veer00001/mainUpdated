import React, { useState } from "react";
import "./Career.css";
import { Button } from "react-bootstrap";
import { vaccancy } from "../../data/data";
import Modal from "react-bootstrap/Modal";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import {
  faLaptop,
  faSchool,
  faCircleInfo,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";

const Career = () => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <div className="careerParant">
      <div className="careerText">
        <h2>BECOME AN INSIDER</h2>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
      </div>

      <div className="vaccancyBox">
        {vaccancy.map((data) => (
          <div>
            <p>{data.name}</p>
            <Button onClick={handleShow}> {data.view}</Button>

            <Modal
              show={show}
              onHide={handleClose}
              backdrop="static"
              keyboard={false}
            >
              <Modal.Body>
                <div className="jobDeatails">
                  <p>
                    <FontAwesomeIcon icon={faLaptop} /> {data.name}
                  </p>
                  <p>
                    {" "}
                    <FontAwesomeIcon icon={faSchool} /> {data.Qualification}
                  </p>
                  <p>
                    {" "}
                    <FontAwesomeIcon icon={faCircleInfo} />
                    {data.Description}
                  </p>
                </div>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  <FontAwesomeIcon icon={faXmark} />
                </Button>
                <Button variant="primary">Apply</Button>
              </Modal.Footer>
            </Modal>
          </div>
        ))}
      </div>
    </div>
  );
};
export default Career;
