import React from "react";

import './ClientsPartnership.css'
import img from './WB/WB-1.jpg'

const ClientsPartnership = () => {
  return <> 
    <div className="ps-3 blue-line-bg">Give A Chance to add your logo with us</div>
  <div className="clientParterParant">
    
  <div className="parterns-images">
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo1.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo2.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo3.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo4.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo5.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo6.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo7.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo8.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo9.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo10.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo11.png"  /> </span>
         <span>  <img src="https://www.webbraininfotech.com/img/client-logo12.png"  /> </span>
    </div>
  </div>
  </>
};

export default ClientsPartnership;
