import React from "react";
import "./About.css";
import img from "./stratergy.png";
import Timeline from "./Timeline";

const About = () => {
  return (

    <div className="services-parant">
      <div className="services">
        <div class="ps-3 blue-line-bg">About Company</div>
        <ul>
          <li>
            <strong>Company Name:</strong> Webeach Tech
          </li>
          <li>
            <strong>Founders:</strong> Privately owned venture founded by one
            entrepreneurs
          </li>
          <li>
            <strong>Headquarters:</strong> Located in New Delhi (NCR), India
          </li>
          <li>
            <strong>Team Composition:</strong> Dynamic team of creative
            professionals in design, marketing, web, and app development
          </li>
          <li>
            <strong>Services Offered:</strong>
            <ul>
              <li>web development/design</li>
              <li>App development/design</li>
              <li>Digital Marketing</li>
            </ul>
          </li>
          <li>
            <strong>Core Competency:</strong> Complete web solutions for clients
          </li>
          <li>
            <strong>Approach:</strong> Technically sound online marketing team
            using pre-planned, result-oriented techniques
          </li>
          <li>
            <strong>Focus Areas:</strong>
            <ul>
              <li>Web Technology</li>
              <li>App Technology</li>
              <li>Online marketing techniques</li>
            </ul>
          </li>
          <li>
            <strong>Philosophy:</strong> Aim for success through strategic
            planning and technical expertise
          </li>
        </ul>
      </div>

      <div className="services-iframe">
        <iframe
          width="100%"
          height="315"
          src="https://www.youtube.com/embed/6NKZ7mscEyY?si=-389YUgPONb-KqVK"
          title="YouTube video player"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowfullscreen
        ></iframe>
        <div>
          <div className="toWacth-heading">
            <p>Building Trust Through Insightful Video Content</p>

            <div className="get-int-trust">
              <p>
                I trust this message finds you well. As part of our ongoing
                commitment to transparency and communication, we invite you to
                watch our latest video, designed to provide valuable insights
                into our organization and the principles that guide us.
              </p>
              <p>
                Name______
                <br />
                Owner Of Company
                <br />
                Wwebeach InfoTech
                <br />
                +91-11-470-51-378
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
