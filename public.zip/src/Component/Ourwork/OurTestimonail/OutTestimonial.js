import React from "react";
import "./OutTestimonial.css";
import { ourTestimonial } from "../../../data/data";

const OutTestimonial = () => {
  return (
    <div className="OurTestimonialParant">
      <h2>Wha The People Think About Us ?</h2>
      <div className="OurTestimonial">
        {ourTestimonial.map((data) => (
          <div>
            <p>{data.Description}</p>
            <span>
              <img src={data.img} alt="Testimonial Images" />{" "}
            </span>
            <div className="testmonialCardName">
              <p>{data.name}</p>
              <p>{data.profession}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OutTestimonial;
