import React from "react";
import "./MainForm.css";

const MainForm = () => {
  return (
    <div className="mainForm-parant">
      <div class="form-container-parant">
        <div class="form-container   form-parant">
          <header>Get In Touch</header>
          <form action="#">
            <div class="form first">
              <div class="details personal">
                {/* <span class="title">Personal Details</span> */}
                <div class="fields">
                <div class="input-field">
                    <label>Full Name</label>
                    <input type="text" placeholder="Enter your name" required />
                  </div>
                  <div class="input-field">
                    <label>Mobile Number</label>
                    <input
                      type="number"
                      placeholder="Enter mobile number"
                      required
                    />
                  </div>

                
                  <div class="input-field">
                    <label>Email</label>
                    <input
                      type="text"
                      placeholder="Enter your email"
                      required
                    />
                  </div>
              
                  <div class="input-field">
                    <label>Your Budget</label>
                    <select required>
                      <option disabled selected>
                       Choose Budget Budget
                      </option>
                      <option>5 $</option>
                      <option>10 $</option>
                      <option>20 $</option>
                    </select>
                  </div>
                  <div class="input-field">
                    <label>Your Region</label>
                    <input
                      type="text"
                      placeholder="Enter your ccupation"
                      required
                    />
                  </div>
          
                  <div class="input-field">
                    <label>Your Country</label>
                    <select required>
                      <option disabled selected>
                      Choose Your Country
                      </option>
                      <option>BHARAT</option>
                      <option>USA</option>
                      <option>SPAIN</option>
                      <option>UK</option>
                    </select>
                  </div>
                  <div class="input-field">
                    <label>Where Did You Here About Us</label>
                    <select required>
                  
                      <option>Instagram</option>
                      <option>LinkedIn</option>
                
                    </select>
                  </div>
                  <div class="input-field">
                    <label>Website Url</label>
                    <input type="text" placeholder="Enter your name" required />
                  </div>
                  <div class="input-field">
                    <label>Message</label>
                    <input type="text" placeholder="write Message" required />
                  </div>
                  <button class="nextBtn">
                    <span class="btnText">Done</span>
                    <i class="uil uil-navigator"></i>
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default MainForm;
