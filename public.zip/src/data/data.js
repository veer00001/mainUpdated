export const clutch = [
  { img: "https://www.webbraininfotech.com/img/Clutch.webp" },
  { img: "https://www.webbraininfotech.com/img/goo-re.png" },
  { img: "https://www.webbraininfotech.com/img/glassdoor-logo.png" },
  { img: "https://www.webbraininfotech.com/img/Clutch.webp" },
  { img: "https://www.webbraininfotech.com/img/justdial_logo.png" },
  { img: "https://www.webbraininfotech.com/img/trustpilot.png" },
];

export const vaccancy = [
  {
    name: "React Developer",
    Qualification: "Graduate",
    Description:
      "Anthonie de Lorme (Tournai 1610 or between 1600 and 1605 – Rotterdam, 1673) was a painter known for his depictions of interiors of existing or imaginary ..",
    view: "View Details",
  },
  {
    name: "Web Developer",
    Qualification: "Post Graduate",
    Description:
      "Anthonie de Lorme (Tournai 1610 or between 1600 and 1605 – Rotterdam, 1673) was a painter known for his depictions of interiors of existing or imaginary ..",
    view: "View Details",
  },
  {
    name: "Graphic Designer",
    Qualification: "under Graduate",
    Description:
      "Anthonie de Lorme (Tournai 1610 or between 1600 and 1605 – Rotterdam, 1673) was a painter known for his depictions of interiors of existing or imaginary ..",
    view: "View Details",
  },
];

export const ourTestimonial = [
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1664575602554-2087b04935a5?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d29tYW58ZW58MHx8MHx8fDA%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://plus.unsplash.com/premium_photo-1686244745070-44e350da9d37?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fHdvbWFufGVufDB8fDB8fHww",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1581803118522-7b72a50f7e9f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTh8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
  {
    Description:
      "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visua.",
    img: "https://images.unsplash.com/photo-1615109398623-88346a601842?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fG1hbnxlbnwwfHwwfHx8MA%3D%3D",
    name: "Nat Reynolds",
    profession: "Accoutns",
  },
];
export const Portfolioimg = [
  {
    Allimg:
      "https://www.webbraininfotech.com/img/Portfolio/amirycashforcars.jpg",
    webImg: "https://www.webbraininfotech.com/img/Portfolio/angelchecks.jpg",
    appImg: "https://www.webbraininfotech.com/img/Portfolio/bentecc.jpg",
    graphic:
      "https://www.webbraininfotech.com/img/Portfolio/cheatingspouse01.jpg",
  },
];

// services

export const webDesign = [
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
  {
    technology: "Static Website",
    Description: "Static website and somethings with informataion",
    bgimg: "",
  },
];

export const SEOservices = [
  { name: "Online Presence Analysis", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "eCommerce SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Content Writing", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Amazon SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Mobile SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Local SEO", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },


];

export const Appservices = [
  { name: " Web apps", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Legacy apps", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Hybrid apps ", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Desktop apps", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: " Native mobile apps", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },
  { name: "Progressive web apps ", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "" },

];
export const AppservicesDemo = [
  { name: "Coputer App", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "https://blog.hootsuite.com/wp-content/uploads/2021/05/all-apps-5.png", status: "done", link: "" },
  { name: "Coputer App", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "https://blog.hootsuite.com/wp-content/uploads/2021/05/all-apps-5.png", status: "done", link: "" },
  { name: "Coputer App", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "https://blog.hootsuite.com/wp-content/uploads/2021/05/all-apps-5.png", status: "done", link: "" },
  { name: "Coputer App", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "https://blog.hootsuite.com/wp-content/uploads/2021/05/all-apps-5.png", status: "done", link: "" },
  { name: "Coputer App", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "https://blog.hootsuite.com/wp-content/uploads/2021/05/all-apps-5.png", status: "done", link: "" },
  { name: "Coputer App", Description: "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.", img: "https://blog.hootsuite.com/wp-content/uploads/2021/05/all-apps-5.png", status: "done", link: "" },
]




// home page

export const AppDevelopmentDesign = [
  { name: " Web apps", img: "" },
  { name: "Legacy apps", img: "" },
  { name: "Hybrid apps ", img: "" },
  { name: "Desktop apps", img: "" },
  { name: " Native mobile apps", img: "" },
  { name: "Progressive web apps ", img: "" }
]
export const WebDevelopmentDesign = [
  { name: "Blogs", img: "" },
  { name: "Static Website", img: "" },
  { name: "Dyamic Website", img: "" },
  { name: "Portfolio", img: "" },
  { name: "eCommerce website", img: "" },
]
export const DigitalMarketing = [
  { name: "Pay-per-click (PPC)", img: "" },
  { name: "Social Media Marketing", img: "" },
  { name: "Search engine optimization (SEO)", img: "" }
]

export const Hosting = [
  { name: "Web Hosting", img: "" },
]


export const GraphicDesign = [
  { name: "Banner", img: "" },
  { name: "Mock-Up", img: "" },
  { name: "Brochure", img: "" },
  { name: "Magazine", img: "" },
  { name: "Animation", img: "" },
  { name: "LOGO design", img: "" },
  { name: "Visiting Card", img: "" },
  { name: "interior design", img: "" },
]



export const mainBanner = [
  { name: "App Development/Design", Description: ` "Empowering your digital vision, we offer bespoke App Development/Design services, seamlessly merging technical expertise with creative prowess to bring your ideas to life in the digital realm."`, link: "/AppDevelopment", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D" },
  { name: "Web Development/Design", Description: `"Transform your online presence with our Web Development/Design services. We seamlessly blend sleek designs, responsive interfaces, and robust development for an engaging user experience."`, link: "/WebDevelopment", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D" },
  { name: "Digital Marketing", Description: ` "Maximize your online impact with our Digital Marketing solutions. From strategic campaigns to targeted outreach, we drive results, helping your brand thrive in the digital landscape."`, link: "/DigitalMarketing", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D" },
  { name: "Graphic Design", Description: `"Ignite visual brilliance with our Graphic Design Services. We bring your ideas to life through captivating visuals that leave a lasting impression."`, link: "/Grahic", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D" },
  { name: "Hosting", Description: `"Reliable and scalable hosting solutions to ensure your website is always up and running. Explore seamless performance and dependable support with our hosting services."`, link: "/Hosting", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8V2ViJTIwZGVzaW5pbmd8ZW58MHx8MHx8fDA%3D" },
]







// app development page 



export const PageAppDevelopmentDesign = [
  { name: " Web apps", img: "", Description: "Web apps, or web applications, are software applications that run on web browsers.", link: "" },
  { name: "Legacy apps", img: "", Description: "Legacy applications, also known as legacy systems or legacy software, refer to older software applications that have been in use for an extended period.", link: "" },
  { name: "Hybrid apps ", img: "", Description: "Hybrid apps are a type of mobile application that combines elements of both native and web applications ", link: "" },
  { name: "Desktop apps", img: "", Description: "Desktop applications, also known as desktop apps or native applications, are software programs designed to run on a user's desktop or laptop computer. ", link: "" },
  { name: " Native mobile apps", img: "", Description: "Native mobile apps are applications developed specifically for a particular mobile operating system (OS) using the platform's native development languages and tools. ", link: "" },
  { name: "Progressive web apps ", img: "", Description: " Progressive Web Apps (PWAs) are a type of web application that leverages modern web technologies to provide a user experience similar to that of native mobile apps. ", link: "" }
]

export const AppDevelopmentBannerImg = [

  { heading: "", Description: "", img: "https://images.unsplash.com/photo-1528795259021-d8c86e14354c?q=80&w=1776&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", point1: "", point2: "", point3: "", point4: "", }
]




// web development page 

export const PageWebDevelopmentDesign = [
  { name: " Web apps", img: "", Description: "Web apps, or web applications, are software applications that run on web browsers.", link: "" },
  { name: "Legacy apps", img: "", Description: "Legacy applications, also known as legacy systems or legacy software, refer to older software applications that have been in use for an extended period.", link: "" },
  { name: "Hybrid apps ", img: "", Description: "Hybrid apps are a type of mobile application that combines elements of both native and web applications ", link: "" },
  { name: "Desktop apps", img: "", Description: "Desktop applications, also known as desktop apps or native applications, are software programs designed to run on a user's desktop or laptop computer. ", link: "" },
  { name: " Native mobile apps", img: "", Description: "Native mobile apps are applications developed specifically for a particular mobile operating system (OS) using the platform's native development languages and tools. ", link: "" },
  { name: "Progressive web apps ", img: "", Description: " Progressive Web Apps (PWAs) are a type of web application that leverages modern web technologies to provide a user experience similar to that of native mobile apps. ", link: "" }
]

export const WebDevelopmentBannerImg = [

  { heading: "", Description: "", img: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", point1: "", point2: "", point3: "", point4: "", }
]
